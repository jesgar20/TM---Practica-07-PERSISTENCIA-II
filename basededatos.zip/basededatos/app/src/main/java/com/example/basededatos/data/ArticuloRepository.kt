package com.example.basededatos.data

import kotlinx.coroutines.flow.Flow

class ArticuloRepository(private val articuloDao: ArticuloDao) {

    // Expone el flujo en tiempo real del Ejercicio 31 hacia la MainActivity
    val todosLosArticulos: Flow<List<Articulo>> = articuloDao.listarTodos()

    suspend fun insertarArticulo(articulo: Articulo) {
        articuloDao.insertar(articulo)
    }

    suspend fun actualizarArticulo(articulo: Articulo) {
        articuloDao.actualizar(articulo)
    }

    suspend fun eliminarArticulo(articulo: Articulo) {
        articuloDao.eliminar(articulo)
    }

    suspend fun buscarPorCodigo(codigo: Int): Articulo? {
        return articuloDao.buscarPorCodigo(codigo)
    }
}