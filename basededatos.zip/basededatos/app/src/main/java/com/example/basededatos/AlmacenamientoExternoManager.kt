package com.example.basededatos

import android.content.Context
import java.io.File
import java.io.IOException

class AlmacenamientoExternoManager(private val context: Context) {

    // Guarda un archivo de texto en el almacenamiento externo dedicado de la app
    fun guardarTextoEnExterno(nombreFichero: String, contenido: String): Boolean {
        return try {
            // Obtiene la ruta de almacenamiento externo (Ej: /storage/emulated/0/Android/data/com.example.basededatos/files)
            val directorioExterno: File? = context.getExternalFilesDir(null)

            if (directorioExterno != null) {
                val fichero = File(directorioExterno, nombreFichero)
                fichero.writeText(contenido) // Escribe el texto de forma nativa en Kotlin
                true
            } else {
                false
            }
        } catch (e: IOException) {
            e.printStackTrace()
            false
        }
    }

    // Lee el contenido de un archivo desde el almacenamiento externo dedicado
    fun leerTextoDeExterno(nombreFichero: String): String? {
        return try {
            val directorioExterno: File? = context.getExternalFilesDir(null)
            val fichero = File(directorioExterno, nombreFichero)

            if (fichero.exists()) {
                fichero.readText() // Retorna el contenido completo del archivo
            } else {
                null
            }
        } catch (e: IOException) {
            e.printStackTrace()
            null
        }
    }
}