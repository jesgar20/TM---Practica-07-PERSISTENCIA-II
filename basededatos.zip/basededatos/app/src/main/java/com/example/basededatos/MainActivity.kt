package com.example.basededatos

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.example.basededatos.data.AppDatabase
import com.example.basededatos.data.Articulo
import com.example.basededatos.data.ArticuloRepository
import com.example.basededatos.databinding.ActivityMainBinding
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var repository: ArticuloRepository

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Inicializar ViewBinding
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Inicializar Base de Datos y Repository
        val database = AppDatabase.getInstance(this)
        repository = ArticuloRepository(database.articuloDao())

        // Eventos de botones
        binding.btnRegistrar.setOnClickListener { registrarProducto() }
        binding.btnBuscar.setOnClickListener { buscarProducto() }
        binding.btnModificar.setOnClickListener { modificarProducto() }
        binding.btnEliminar.setOnClickListener { eliminarProducto() }


        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                repository.todosLosArticulos.collect { listaDeArticulos ->
                    actualizarInterfaz(listaDeArticulos)
                }
            }
        }
    }

    // =========================
    // REGISTRAR
    // =========================

    private fun registrarProducto() {

        val codStr = binding.txtCodigo.text.toString()
        val desc = binding.txtDescripcion.text.toString()
        val preStr = binding.txtPrecio.text.toString()

        if (codStr.isEmpty() || desc.isEmpty() || preStr.isEmpty()) {
            Toast.makeText(
                this,
                "Debe llenar todos los campos",
                Toast.LENGTH_SHORT
            ).show()
            return
        }

        val articulo = Articulo(
            codigo = codStr.toInt(),
            descripcion = desc,
            precio = preStr.toDouble()
        )

        lifecycleScope.launch {
            try {

                repository.insertarArticulo(articulo)

                limpiarCampos()

                Toast.makeText(
                    this@MainActivity,
                    "Registro exitoso",
                    Toast.LENGTH_SHORT
                ).show()

            } catch (e: Exception) {

                Toast.makeText(
                    this@MainActivity,
                    "Error al registrar: ${e.message}",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }

    // =========================
    // BUSCAR
    // =========================

    private fun buscarProducto() {

        val codStr = binding.txtCodigo.text.toString()

        if (codStr.isEmpty()) {

            Toast.makeText(
                this,
                "Ingrese un código para buscar",
                Toast.LENGTH_SHORT
            ).show()

            return
        }

        lifecycleScope.launch {

            val articulo = repository.buscarPorCodigo(codStr.toInt())

            if (articulo != null) {

                binding.txtDescripcion.setText(articulo.descripcion)
                binding.txtPrecio.setText(articulo.precio.toString())

                Toast.makeText(
                    this@MainActivity,
                    "Artículo encontrado",
                    Toast.LENGTH_SHORT
                ).show()

            } else {

                Toast.makeText(
                    this@MainActivity,
                    "No existe un artículo con dicho código",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }

    // =========================
    // MODIFICAR
    // =========================

    private fun modificarProducto() {

        val codStr = binding.txtCodigo.text.toString()
        val desc = binding.txtDescripcion.text.toString()
        val preStr = binding.txtPrecio.text.toString()

        if (codStr.isEmpty() || desc.isEmpty() || preStr.isEmpty()) {

            Toast.makeText(
                this,
                "Debe llenar todos los campos para modificar",
                Toast.LENGTH_SHORT
            ).show()

            return
        }

        lifecycleScope.launch {

            val articuloExistente =
                repository.buscarPorCodigo(codStr.toInt())

            if (articuloExistente != null) {

                val articuloModificado = Articulo(
                    id = articuloExistente.id,
                    codigo = codStr.toInt(),
                    descripcion = desc,
                    precio = preStr.toDouble()
                )

                repository.actualizarArticulo(articuloModificado)

                limpiarCampos()

                Toast.makeText(
                    this@MainActivity,
                    "Artículo modificado con éxito",
                    Toast.LENGTH_SHORT
                ).show()

            } else {

                Toast.makeText(
                    this@MainActivity,
                    "No se puede modificar un artículo inexistente",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }

    // =========================
    // ELIMINAR
    // =========================

    private fun eliminarProducto() {

        val codStr = binding.txtCodigo.text.toString()

        if (codStr.isEmpty()) {

            Toast.makeText(
                this,
                "Ingrese un código para eliminar",
                Toast.LENGTH_SHORT
            ).show()

            return
        }

        lifecycleScope.launch {

            val articuloExistente =
                repository.buscarPorCodigo(codStr.toInt())

            if (articuloExistente != null) {

                repository.eliminarArticulo(articuloExistente)

                limpiarCampos()

                Toast.makeText(
                    this@MainActivity,
                    "Artículo eliminado con éxito",
                    Toast.LENGTH_SHORT
                ).show()

            } else {

                Toast.makeText(
                    this@MainActivity,
                    "No existe ningún artículo con ese código",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }

    // =========================
    // MÉTODOS AUXILIARES
    // =========================

    private fun actualizarInterfaz(lista: List<Articulo>) {

        println(
            "Cambio observado en tiempo real: Contiene ${lista.size} elementos."
        )

        // Opcional:
        // binding.tvResultadoCompleto.text = lista.toString()
    }

    private fun limpiarCampos() {

        binding.txtCodigo.setText("")
        binding.txtDescripcion.setText("")
        binding.txtPrecio.setText("")
    }
}