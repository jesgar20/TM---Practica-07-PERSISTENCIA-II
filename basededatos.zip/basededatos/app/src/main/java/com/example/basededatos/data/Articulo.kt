package com.example.basededatos.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "articulos")
data class Articulo(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val codigo: Int,
    val descripcion: String,
    val precio: Double
)